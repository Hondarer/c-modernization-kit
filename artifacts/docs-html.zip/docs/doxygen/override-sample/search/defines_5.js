var searchData=
[
  ['module_5fhandle_0',['MODULE_HANDLE',['../libbase_8h.html#a2cb1993b274d4b60febe53b80d0ef454',1,'libbase.h']]]
];
