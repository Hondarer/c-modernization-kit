var searchData=
[
  ['winapi_0',['WINAPI',['../libbase_8h.html#a9aa60e1ead64be77ad551e745cbfd4d3',1,'WINAPI:&#160;libbase.h'],['../libbase__ext_8h.html#a9aa60e1ead64be77ad551e745cbfd4d3',1,'WINAPI:&#160;libbase_ext.h']]]
];
