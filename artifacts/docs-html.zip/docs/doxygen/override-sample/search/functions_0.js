var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../dllmain_8h.html#a4d4bf980742769db8ad7ca3fdd754ab6',1,'__attribute__((constructor)) static void dllmain_on_load__(void):&#160;dllmain.h'],['../dllmain_8h.html#a6f20f5f9db695531c457be9a609e05e3',1,'__attribute__((destructor)) static void dllmain_on_unload__(void):&#160;dllmain.h']]],
  ['_5ffuncman_5fget_5ffunc_1',['_funcman_get_func',['../libbase_8h.html#a3d206cca6cf4241fbbf1b10be7c8714c',1,'_funcman_get_func(funcman_object *fobj):&#160;funcman_get_func.c'],['../funcman__get__func_8c.html#acb47786bbf6ea8a7edef3562a896765d',1,'_funcman_get_func(funcman_object *fobj):&#160;funcman_get_func.c']]]
];
