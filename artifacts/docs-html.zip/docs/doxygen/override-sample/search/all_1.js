var searchData=
[
  ['base_5fapi_0',['BASE_API',['../libbase_8h.html#a3415806957cd45a6e3791e6122ec65dd',1,'libbase.h']]],
  ['base_5fext_5fapi_1',['BASE_EXT_API',['../libbase__ext_8h.html#a5d75b9926bd3e9e3887be3706df329c2',1,'libbase_ext.h']]]
];
