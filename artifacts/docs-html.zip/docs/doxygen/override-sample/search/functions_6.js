var searchData=
[
  ['sample_5ffunc_0',['sample_func',['../libbase_8h.html#a9f8eef56c9f0d9a18600630d14003264',1,'sample_func(const int a, const int b, int *result):&#160;sample_func.c'],['../sample__func_8c.html#ad27d814cdde25db39d4a08df33f6754b',1,'sample_func(const int a, const int b, int *result):&#160;sample_func.c']]],
  ['strip_5fextension_5finplace_1',['strip_extension_inplace',['../get__lib__info_8c.html#a6a4373ad8047dc25256fd9320083d960',1,'get_lib_info.c']]]
];
