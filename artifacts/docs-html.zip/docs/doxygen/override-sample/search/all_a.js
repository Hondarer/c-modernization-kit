var searchData=
[
  ['new_5ffuncman_5fobject_0',['NEW_FUNCMAN_OBJECT',['../libbase_8h.html#a8c9c49693e5583c4c4a25f5183ed9d1f',1,'libbase.h']]]
];
