var searchData=
[
  ['get_5flib_5finfo_2ec_0',['get_lib_info.c',['../get__lib__info_8c.html',1,'']]]
];
