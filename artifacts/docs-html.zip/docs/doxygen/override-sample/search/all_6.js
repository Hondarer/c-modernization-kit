var searchData=
[
  ['handle_0',['handle',['../structfuncman__object.html#a166032f130a790ea8f42c5431f79218f',1,'funcman_object']]]
];
