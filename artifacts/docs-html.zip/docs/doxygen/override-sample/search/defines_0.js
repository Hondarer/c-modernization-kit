var searchData=
[
  ['_5fgnu_5fsource_0',['_GNU_SOURCE',['../libbase_8h.html#a369266c24eacffb87046522897a570d5',1,'libbase.h']]]
];
