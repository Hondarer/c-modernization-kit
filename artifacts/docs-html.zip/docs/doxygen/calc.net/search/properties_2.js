var searchData=
[
  ['value_0',['Value',['../classCalcLib_1_1CalcResult.html#a7412c9f344128fd2953125ae64ffa471',1,'CalcLib::CalcResult']]]
];
