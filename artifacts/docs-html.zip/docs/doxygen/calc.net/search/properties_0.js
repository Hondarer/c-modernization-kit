var searchData=
[
  ['errorcode_0',['ErrorCode',['../classCalcLib_1_1CalcException.html#a5d06dedb0f225daac2192f27ed5d6bf5',1,'CalcLib.CalcException.ErrorCode'],['../classCalcLib_1_1CalcResult.html#ae13f52d89ccc02587c9a7783243f693f',1,'CalcLib.CalcResult.ErrorCode']]]
];
