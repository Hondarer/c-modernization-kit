var searchData=
[
  ['subtract_0',['Subtract',['../namespaceCalcLib.html#a6dd686b9dadaee39b103ca22954f1ab0a1d9baf077ee87921f57a8fe42d510b65',1,'CalcLib']]]
];
