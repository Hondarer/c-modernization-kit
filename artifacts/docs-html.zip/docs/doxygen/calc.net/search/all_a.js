var searchData=
[
  ['subtract_0',['Subtract',['../classCalcLib_1_1CalcLibrary.html#ae33b60debce6081d9bf76c2bb08cf2ff',1,'CalcLib.CalcLibrary.Subtract()'],['../namespaceCalcLib.html#a6dd686b9dadaee39b103ca22954f1ab0a1d9baf077ee87921f57a8fe42d510b65',1,'CalcLib.Subtract']]]
];
