var searchData=
[
  ['calcexception_0',['CalcException',['../classCalcLib_1_1CalcException.html#adc24caba12cefba8b34f7c5533cd1da2',1,'CalcLib.CalcException.CalcException(int errorCode, string message)'],['../classCalcLib_1_1CalcException.html#afe521b902ad134aa9607ac8184d2d558',1,'CalcLib.CalcException.CalcException(int errorCode, string message, Exception innerException)']]],
  ['calculate_1',['Calculate',['../classCalcLib_1_1CalcLibrary.html#a34a86f8468ea21ed264e06c6074984f4',1,'CalcLib::CalcLibrary']]],
  ['calculateorthrow_2',['CalculateOrThrow',['../classCalcLib_1_1CalcLibrary.html#a2a5d124125389d3ff10bf82898c9a732',1,'CalcLib::CalcLibrary']]]
];
