var searchData=
[
  ['add_0',['Add',['../namespaceCalcLib.html#a6dd686b9dadaee39b103ca22954f1ab0aec211f7c20af43e742bf2570c3cb84f9',1,'CalcLib']]]
];
