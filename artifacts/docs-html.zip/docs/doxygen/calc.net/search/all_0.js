var searchData=
[
  ['add_0',['Add',['../classCalcLib_1_1CalcLibrary.html#abaead7304154caeb83e885276ce81f0d',1,'CalcLib.CalcLibrary.Add()'],['../namespaceCalcLib.html#a6dd686b9dadaee39b103ca22954f1ab0aec211f7c20af43e742bf2570c3cb84f9',1,'CalcLib.Add']]]
];
