var searchData=
[
  ['subtract_0',['Subtract',['../classCalcLib_1_1CalcLibrary.html#ae33b60debce6081d9bf76c2bb08cf2ff',1,'CalcLib::CalcLibrary']]]
];
