var searchData=
[
  ['arch_5farm_0',['ARCH_ARM',['../platform_8h.html#a672a002d8ba874ce01b980e058013b22',1,'platform.h']]],
  ['arch_5farm64_1',['ARCH_ARM64',['../platform_8h.html#a405e8a81cfa55965f474894e2ad3187f',1,'platform.h']]],
  ['arch_5fname_2',['ARCH_NAME',['../platform_8h.html#aa241f94fb14a067550ddaa93a6e59309',1,'platform.h']]],
  ['arch_5funknown_3',['ARCH_UNKNOWN',['../platform_8h.html#ab12acdd95c5d99a53c114b49b2f62b9c',1,'platform.h']]],
  ['arch_5fx64_4',['ARCH_X64',['../platform_8h.html#af40ba0f45e16530bd8fe94e8d148b7cb',1,'platform.h']]],
  ['arch_5fx86_5',['ARCH_X86',['../platform_8h.html#a65832c64d11f7625ea4b31eedd122442',1,'platform.h']]]
];
