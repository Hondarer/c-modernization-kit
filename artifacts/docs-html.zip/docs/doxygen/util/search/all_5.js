var searchData=
[
  ['stat_5fprintf_0',['stat_printf',['../file-util_8h.html#a26f2510a67b9f01b69ebdc6b741feed7',1,'stat_printf(file_stat_t *buf, const char *format,...):&#160;file-util.c'],['../file-util_8c.html#abc1162eda80e466859eb1621cf696656',1,'stat_printf(file_stat_t *buf, const char *format,...):&#160;file-util.c']]]
];
