var searchData=
[
  ['platform_2eh_0',['platform.h',['../platform_8h.html',1,'']]],
  ['platform_5fapple_5fother_1',['PLATFORM_APPLE_OTHER',['../platform_8h.html#a87f673fcf6887fc960bbe60764350c47',1,'platform.h']]],
  ['platform_5flinux_2',['PLATFORM_LINUX',['../platform_8h.html#affcc3790504b838f9ce56a008cce0950',1,'platform.h']]],
  ['platform_5fmacos_3',['PLATFORM_MACOS',['../platform_8h.html#adc8a222635840a41e1f36602434662c1',1,'platform.h']]],
  ['platform_5fname_4',['PLATFORM_NAME',['../platform_8h.html#aa4688daf0f1e6dda714351a6e5a394c2',1,'platform.h']]],
  ['platform_5funknown_5',['PLATFORM_UNKNOWN',['../platform_8h.html#a8e581b101ce12660f12591291f5c72f6',1,'platform.h']]],
  ['platform_5fwindows_6',['PLATFORM_WINDOWS',['../platform_8h.html#a20cd3c4775f1897fb5658d2dc61382c3',1,'platform.h']]]
];
