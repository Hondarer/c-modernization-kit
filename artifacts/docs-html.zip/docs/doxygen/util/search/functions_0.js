var searchData=
[
  ['fopen_5fprintf_0',['fopen_printf',['../file-util_8h.html#a591c09d61c5aa752bc1150231a8c0593',1,'fopen_printf(const char *modes, int *errno_out, const char *format,...):&#160;file-util.c'],['../file-util_8c.html#a3cb5f9c9cb8c1488ed003beff2e2e225',1,'fopen_printf(const char *modes, int *errno_out, const char *format,...):&#160;file-util.c']]]
];
