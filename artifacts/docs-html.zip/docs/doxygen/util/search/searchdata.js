var indexSectionsWithContent =
{
  0: "acfnpswアイコプ使",
  1: "cfp",
  2: "fs",
  3: "f",
  4: "acfnpw",
  5: "アイコプ使"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Macros",
  5: "Pages"
};

