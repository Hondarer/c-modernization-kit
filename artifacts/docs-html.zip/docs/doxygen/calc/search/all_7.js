var searchData=
[
  ['readme_2ecalc_2emd_0',['README.calc.md',['../README_8calc_8md.html',1,'']]],
  ['readme_2emd_1',['README.md',['../README_8md.html',1,'(Global Namespace)'],['../src_2add_2README_8md.html',1,'(Global Namespace)'],['../src_2calc_2README_8md.html',1,'(Global Namespace)'],['../src_2README_8md.html',1,'(Global Namespace)'],['../src_2shared-and-static-calc_2README_8md.html',1,'(Global Namespace)']]]
];
