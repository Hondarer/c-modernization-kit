var indexSectionsWithContent =
{
  0: "acdiklmrswコサ",
  1: "acdilmrs",
  2: "acdms",
  3: "cw",
  4: "ckmコサ"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros",
  4: "Pages"
};

