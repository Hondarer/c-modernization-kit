var searchData=
[
  ['add_0',['add',['../libcalcbase_8h.html#ae0a73dcc2e58d59cbc0f200e50736260',1,'add(const int a, const int b, int *result):&#160;add.c'],['../libsrc_2calcbase_2add_8c.html#ae0a73dcc2e58d59cbc0f200e50736260',1,'add(const int a, const int b, int *result):&#160;add.c']]],
  ['add_2ec_1',['add.c',['../libsrc_2calcbase_2add_8c.html',1,'(Global Namespace)'],['../src_2add_2add_8c.html',1,'(Global Namespace)']]]
];
