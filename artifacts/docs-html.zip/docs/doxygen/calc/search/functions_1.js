var searchData=
[
  ['calchandler_0',['calcHandler',['../libcalc_8h.html#a642fe53112def0e783784459698b3318',1,'calcHandler(const int kind, const int a, const int b, int *result):&#160;calcHandler.c'],['../calcHandler_8c.html#a076a4c6ceba865f94fc475a5411115f7',1,'calcHandler(const int kind, const int a, const int b, int *result):&#160;calcHandler.c']]]
];
