var searchData=
[
  ['divide_0',['divide',['../libcalcbase_8h.html#a457d7ab9fae4d04f0083aeeee6c700bb',1,'divide(const int a, const int b, int *result):&#160;divide.c'],['../divide_8c.html#a457d7ab9fae4d04f0083aeeee6c700bb',1,'divide(const int a, const int b, int *result):&#160;divide.c']]],
  ['divide_2ec_1',['divide.c',['../divide_8c.html',1,'']]]
];
