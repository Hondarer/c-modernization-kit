var searchData=
[
  ['winapi_0',['WINAPI',['../libcalc_8h.html#a9aa60e1ead64be77ad551e745cbfd4d3',1,'libcalc.h']]]
];
