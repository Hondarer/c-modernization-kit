var searchData=
[
  ['main_0',['main',['../src_2add_2add_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;add.c'],['../calc_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;calc.c'],['../shared-and-static-calc_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;shared-and-static-calc.c']]],
  ['multiply_1',['multiply',['../libcalcbase_8h.html#aa2620c22f253b878c0356f0df6ac6d61',1,'multiply(const int a, const int b, int *result):&#160;multiply.c'],['../multiply_8c.html#aa2620c22f253b878c0356f0df6ac6d61',1,'multiply(const int a, const int b, int *result):&#160;multiply.c']]]
];
