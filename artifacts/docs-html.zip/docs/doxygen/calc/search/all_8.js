var searchData=
[
  ['shared_2dand_2dstatic_2dcalc_2ec_0',['shared-and-static-calc.c',['../shared-and-static-calc_8c.html',1,'']]],
  ['subtract_1',['subtract',['../libcalcbase_8h.html#a1bf275b5894cc190077fcae5246956ac',1,'subtract(const int a, const int b, int *result):&#160;subtract.c'],['../subtract_8c.html#a1bf275b5894cc190077fcae5246956ac',1,'subtract(const int a, const int b, int *result):&#160;subtract.c']]],
  ['subtract_2ec_2',['subtract.c',['../subtract_8c.html',1,'']]]
];
