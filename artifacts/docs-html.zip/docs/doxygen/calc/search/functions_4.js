var searchData=
[
  ['subtract_0',['subtract',['../libcalcbase_8h.html#a1bf275b5894cc190077fcae5246956ac',1,'subtract(const int a, const int b, int *result):&#160;subtract.c'],['../subtract_8c.html#a1bf275b5894cc190077fcae5246956ac',1,'subtract(const int a, const int b, int *result):&#160;subtract.c']]]
];
