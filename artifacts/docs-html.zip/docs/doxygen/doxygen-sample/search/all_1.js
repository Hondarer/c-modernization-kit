var searchData=
[
  ['b_0',['b',['../structSAMPLE__STRUCT.html#a08cf2a6f5ea65c3f4f463a6055c312ef',1,'SAMPLE_STRUCT']]],
  ['bullets_1',['bullets',['../bullets_8h.html#abfb707e37aac970d2708e604786faa7e',1,'bullets.h']]],
  ['bullets_2eh_2',['bullets.h',['../bullets_8h.html',1,'']]]
];
