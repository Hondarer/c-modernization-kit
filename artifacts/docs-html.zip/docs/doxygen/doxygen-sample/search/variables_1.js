var searchData=
[
  ['b_0',['b',['../structSAMPLE__STRUCT.html#a08cf2a6f5ea65c3f4f463a6055c312ef',1,'SAMPLE_STRUCT']]]
];
